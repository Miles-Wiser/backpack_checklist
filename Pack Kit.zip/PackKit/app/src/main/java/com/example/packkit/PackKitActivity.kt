package com.example.packkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.packkit.ui.more.MoreScreen
import com.example.packkit.ui.theme.PackKitTheme
import com.example.packkit.ui.trip.TripScreen


class PackKitActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PackKitApp()
        }
    }
}

@Composable
fun PackKitApp() {
    PackKitTheme {
        Scaffold(
            bottomBar = { Footer() },
        ) { paddingValues ->
            val navController = rememberNavController()

            // TODO: Figure out how to navigate to different screens.
            NavHost(
                navController = navController,
                startDestination = "home"
            ) {
                composable(route = "home") {
                    TripScreen(
                        onNavToDetails = { navController.navigate("details") },
                        modifier = Modifier.padding(paddingValues)
                        )
                }
                composable(route = "more") {
                    MoreScreen(
                        modifier = Modifier.padding(paddingValues)
                    )
                }
            }
//
        }
    }
}

/**
 * Creates a button that opens a menu to add a trip.
 */
// TODO: Make this function add a trip. Must work on data saving first?
//@Composable
//fun AddTrip() {
//    Button(
//        onClick = { /* TODO: Add Functionality */ },
//    ) {
//
//    }
//}

/**
 * Displays the bottom bar and navigational buttons.
 */
@Composable
fun Footer() {
    Row(
        modifier = Modifier
//            TODO: Figure out how to apply colors correctly
            .background(Color.DarkGray)
            .padding(bottom = 20.dp)
            .height(120.dp)
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        // TODO: Change "Add" to get the screen so it will change to "Add Trip", "Share", ect.
        FooterIcon(R.drawable.ic_add, "Add")
        FooterIcon(R.drawable.ic_home, "Home")
        FooterIcon(R.drawable.ic_more, "More")
    }
}

/**
 * Displays a navigational button for the bottom bar.
 *
 * @param imgId The reference id for the button's image.
 * @param description The description for the button.
 */
@Composable
fun FooterIcon(imgId: Int, description: String) {
    Button(
        onClick = { /* TODO: Add navigational functionality */ }
    ) {
        Column(
            modifier = Modifier
                .widthIn(min = 50.dp, max = 70.dp)
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(imgId),
                contentDescription = description,
                modifier = Modifier
            )
            Text(description)
        }
    }
}