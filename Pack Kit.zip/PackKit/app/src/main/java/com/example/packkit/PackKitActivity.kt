package com.example.packkit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.packkit.ui.more.MoreScreen
import com.example.packkit.ui.theme.PackKitTheme
import com.example.packkit.ui.trip.Footer
import com.example.packkit.ui.trip.TripScreen


class PackKitActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PackKitApp()
        }
    }
}

@Composable
fun PackKitApp() {
    PackKitTheme {
        Scaffold(
            bottomBar = { Footer() }
        ) { paddingValues ->
//            TripScreen(modifier = Modifier.padding(paddingValues))
            MoreScreen(modifier = Modifier.padding(paddingValues))
        }
    }
}