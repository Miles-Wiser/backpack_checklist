package com.example.packkit.ui.trip

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.packkit.R
import com.example.packkit.ui.theme.PackKitTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PackKitTheme {
                Scaffold(
                    bottomBar = { Footer(Modifier) }
                ) { paddingValues ->
                    TripList(paddingValues)
                }
            }
        }
    }
}

@Composable
fun Footer(modifier: Modifier) {
    Row(
        modifier = modifier
//            TODO: Figure out how to apply colors correctly
            .background(Color(R.color.teal_200))
            .padding(bottom = 20.dp)
            .height(120.dp)
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        FooterIcon(R.drawable.ic_home, "Home")
        FooterIcon(R.drawable.ic_more, "More")
    }
}

@Composable
fun FooterIcon(imgId: Int, description: String) {
    Button(
        onClick = { /* TODO: Add navigational functionality */ }
    ) {
        Column(
            modifier = Modifier
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(imgId),
                contentDescription = description,
                modifier = Modifier
            )
            Text(description)
        }
    }
}

@Composable
fun TripList(paddingValues: PaddingValues) {
    Column(
        modifier = Modifier
            .padding(paddingValues)
    ) {
        Text("Next Trip", modifier = Modifier.padding(8.dp))
        TripCard()

        Row(
            modifier = Modifier.padding(8.dp)
        ) {
            Text(
                text = "Upcoming Trips",
                modifier = Modifier.weight(2f)
            )
            AddTrip()
        }

        LazyColumn {
            items(3) {
                TripCard()

            }
        }

        Text("Past Trips", modifier = Modifier.padding(8.dp))
        LazyColumn {
            items(9) {
                TripCard()

            }
        }
    }
}

@Composable
fun TripCard() {
    Row(
        modifier = Modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(
            modifier = Modifier
                .padding(start = 24.dp, top = 10.dp, bottom = 10.dp)
                .weight(2f),
            onClick = { /* TODO: Make navigationally functional */ }
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.Start,
            ) {
                Text("Soonest Trip")
                Text("Date: MM/DD/YY")
            }
        }
        FilledTonalButton(
            modifier = Modifier
                .padding(start = 8.dp, top = 10.dp, bottom = 10.dp, end = 24.dp)
                .weight(1f),
            onClick = { /* TODO: Make navigationally functional */ }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_delete),
                    contentDescription = "Trash",
                    modifier = Modifier
                )
                Text("Trash")
            }
        }
    }
}

@Composable
fun AddTrip() {
    Button(
        onClick = { /* TODO: Add Functionality */ },
    ) {
        Image(
            painter = painterResource(R.drawable.ic_add),
            contentDescription = "Add Trip",
        )
        Text("Add Trip")
    }
}