package com.example.packkit.ui.trip

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.packkit.R

/**
 * Displays all trips in a LazyColumn. Each segment of trips is separated by headers.
 *
 * @param paddingValues This is necessary for Scaffold(). Don't really know what it is for.
 */
@Composable
fun TripScreen(modifier: Modifier) {
    val scrollState = rememberLazyListState()
    LazyColumn(
        state = scrollState,
        modifier = Modifier
//            .padding(paddingValues)
    ) {

        // Next Trip Header and element
        item {
            Text(
                "Next Trip",
                modifier = Modifier.padding(20.dp)
            )
            TripCard()
        }

        // Upcoming Trip(s) Header
        item {
            Row (
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Upcoming Trips",
                    modifier = Modifier.weight(2f)
                )
                AddTrip()
            }
        }

        // Upcoming Trip(s) Element(s)
        //TODO: Use trips not a random number

        items(count = 3) {
            TripCard()
        }

        // Past Trip(s) Header
        //TODO: Use trips not a random number
        item {
            Text(
                "Past Trips",
                modifier = Modifier.padding(20.dp)
            )
        }

        // Past Trip(s) Element(s)
        items(7) {
            TripCard()

        }
    }
}

/**
 * Displays the bottom bar and navigational buttons.
 */
@Composable
fun Footer() {
    Row(
        modifier = Modifier
//            TODO: Figure out how to apply colors correctly
            .background(Color.DarkGray)
            .padding(bottom = 20.dp)
            .height(120.dp)
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        FooterIcon(R.drawable.ic_home, "Home")
        FooterIcon(R.drawable.ic_more, "More")
    }
}

/**
 * Displays a navigational button for the bottom bar.
 *
 * @param imgId The reference id for the button's image.
 * @param description The description for the button.
 */
@Composable
fun FooterIcon(imgId: Int, description: String) {
    Button(
        onClick = { /* TODO: Add navigational functionality */ }
    ) {
        Column(
            modifier = Modifier
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(imgId),
                contentDescription = description,
                modifier = Modifier
            )
            Text(description)
        }
    }
}

/**
 * Creates a navigational button to link to a trip.
 */
@Composable
fun TripCard() {
    Row(
        modifier = Modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilledTonalButton(
            modifier = Modifier
                .padding(start = 24.dp, top = 10.dp, bottom = 10.dp)
                .weight(2f),
            onClick = { /* TODO: Make navigationally functional */ }
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.Start,
            ) {
                Text("Soonest Trip")
                Text("Date: MM/DD/YY")
            }
        }
        FilledTonalButton(
            modifier = Modifier
                .padding(start = 8.dp, top = 10.dp, bottom = 10.dp, end = 24.dp)
                .weight(1f),
            onClick = { /* TODO: Make navigationally functional */ }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_delete),
                    contentDescription = "Trash",
                    modifier = Modifier
                )
                Text("Trash")
            }
        }
    }
}

/**
 * Creates a button that opens a menu to add a trip.
 */
@Composable
fun AddTrip() {
    Button(
        onClick = { /* TODO: Add Functionality */ },
    ) {
        Image(
            painter = painterResource(R.drawable.ic_add),
            contentDescription = "Add Trip",
        )
        Text("Add Trip")
    }
}