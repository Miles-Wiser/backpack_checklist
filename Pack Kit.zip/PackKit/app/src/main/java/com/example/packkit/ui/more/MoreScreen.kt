package com.example.packkit.ui.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


@Composable
fun MoreScreen(modifier: Modifier) {
//    TODO: Use the dropdown menu thingy
    val tabs = listOf(
        Tabs("Notifications", "Manage alerts and updates"),
        Tabs("Preferences", "Customize your experience"),
        Tabs("Tutorial", "Learn how to use the app"),
        Tabs("Experience Survey", "Tell us what you think"),
        Tabs("test","test")
    )

    LazyColumn(
        modifier = modifier
            .padding(20.dp)
    ) {
        items(tabs.size) { index ->
            MoreTab(
                title = tabs[index].title,
                description = tabs[index].description,
                functional = false
            )
        }
    }
}


@Composable
fun MoreTab(title: String, description: String, functional: Boolean = true) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Text(
            text = title,
            modifier = Modifier
                .fillMaxWidth()
                .clickable( onClick = { } )
        )

        if (!functional) {
            Text("Currently Unavailable!",)
        }
    }
}

data class Tabs(
    val title: String,
    val description: String
)