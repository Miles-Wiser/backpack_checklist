package com.example.packkit.ui.more

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


@Composable
fun MoreScreen(modifier: Modifier) {
//    TODO: Use the dropdown menu thingy
    val tabs = listOf(
        Tabs("Notifications", ""),
        Tabs("Preferences", ""),
        Tabs("App Tutorial", "Learn how to use the app."),
        Tabs("Experience Survey", "Take this to autofill certain criteria."),
    )

    LazyColumn(
        modifier = modifier
            .padding(20.dp)
    ) {
        items(tabs.size) { index ->
            MoreTab(
                title = tabs[index].title,
                description = tabs[index].description,
                isFunctional = false
            )
        }
    }
}


@Composable
fun MoreTab(title: String, description: String, isFunctional: Boolean = true) {
    var isExpanded by remember { mutableStateOf(false) }

    var functionalMsg = description
    if (!isFunctional) {functionalMsg = "Currently Unavailable!"}

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded}
    ) {
        Text(
            text = "$title\n$functionalMsg",
            modifier = Modifier
                .fillMaxWidth(),
            maxLines = if (isExpanded) Int.MAX_VALUE else 1
        )
    }
}

data class Tabs(
    val title: String,
    val description: String
)